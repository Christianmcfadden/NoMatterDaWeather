"""
NoMatterDaWeather (Web App)

Contributers:
Christian Mcfadden


Date Started: 12/7/24

File: __init__.py
"""
import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from flask_login import LoginManager
from flask_bcrypt import Bcrypt

"""
You must install the requirements.txt *(IF NEEDED NMDW was mine)
create virtual environment --> (python -m venv "myvenv") <-- name of environment

Activate Environment

* On windows -->   name of environment -->`("myvenv"\Scripts\activate`)
* On mac -->   source ("myvenv"/bin/activate) (Name is in "")

Install requirement packages
(pip install -r requirements.txt) 

"""

app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(24)
app.debug = True

#I am going to use sql to store user info
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
db = SQLAlchemy(app)

# i might use firebase to handle login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"

#Encoding integration
bcrypt = Bcrypt(app)



from NMDW import routes